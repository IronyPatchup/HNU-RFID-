import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QStackedWidget,
                              QVBoxLayout, QLabel, QPushButton,
                              QComboBox, QMessageBox, QToolBar)
from PySide6.QtCore import QThread, Signal, QMutex, Qt, QMutexLocker
from PySide6.QtGui import QPixmap
import serial
from serial.tools import list_ports

# ==================== 串口通信线程类 ====================
class SerialThread(QThread):
    data_received = Signal(bytes)
    status_updated = Signal(int, str)
    error_occurred = Signal(str)
    connection_changed = Signal(bool)

    def __init__(self):
        super().__init__()
        self.mutex = QMutex()
        self.ser = None
        self.running = True
        self.connected_flag = False
        self.current_mode = 1
        self.port = ""
        self.baudrate = 115200

    def run(self):
        while self.running:
            if self.ser and self.ser.is_open and self.connected_flag:
                try:
                    if self.ser.in_waiting:
                        data = self.ser.read_all()
                        self.parse_data(data)
                except Exception as e:
                    self.error_occurred.emit(f"串口读取错误: {str(e)}")
                QThread.msleep(10)

    def connect_serial(self, port, baudrate):
        with QMutexLocker(self.mutex):
            try:
                if self.ser and self.ser.is_open:
                    self.ser.close()
                self.ser = serial.Serial(port=port, baudrate=baudrate,
                                        parity=serial.PARITY_NONE,
                                        stopbits=serial.STOPBITS_ONE,
                                        timeout=0.5)
                self.port = port
                self.baudrate = baudrate
                self.connected_flag = True
                self.connection_changed.emit(True)
                return True
            except Exception as e:
                self.error_occurred.emit(f"连接失败: {str(e)}")
                self.connection_changed.emit(False)
                return False

    def disconnect_serial(self):
        with QMutexLocker(self.mutex):
            if self.ser and self.ser.is_open:
                try:
                    self.ser.close()
                except Exception:
                    pass
            self.connected_flag = False
        self.connection_changed.emit(False)

    def send_mode_command(self, mode_value):
        return self.send_command(0x20, bytes([mode_value]))

    def send_command(self, cmd, data=bytes()):
        with QMutexLocker(self.mutex):
            if not (self.ser and self.ser.is_open):
                self.error_occurred.emit("串口未连接")
                return False
            try:
                frame = bytes([0xAA, cmd, len(data)]) + data
                frame += bytes([sum(frame[1:]) & 0xFF])
                self.ser.write(frame)
                return True
            except Exception as e:
                self.error_occurred.emit(f"发送失败: {str(e)}")
                return False

    def parse_data(self, data):
        if len(data) < 4 or data[0] != 0xAA:
            return
        cmd, length = data[1], data[2]
        payload = data[3:3+length]
        if cmd == 0x01:
            status = "开启" if payload[0] else "关闭"
            self.status_updated.emit(1, status)
        elif cmd == 0x20 and payload and payload[0] == 0x01:
            self.current_mode = payload[1]
            self.status_updated.emit(5, f"模式切换成功:{self.current_mode}")

# ==================== 主窗口类 ====================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.serial_thread = SerialThread()
        self.emergency_mode = False
        self.is_door_open = False
        self.init_ui()
        self.init_serial()
        self.setWindowTitle("智能门禁控制系统")
        self.resize(600, 400)

    def init_ui(self):
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.create_serial_toolbar()
        self.create_mode_toolbar()
        self.init_mode_uis()

    def create_serial_toolbar(self):
        toolbar = QToolBar()
        self.addToolBar(Qt.TopToolBarArea, toolbar)
        self.port_combo = QComboBox()
        self.refresh_ports()
        self.baud_combo = QComboBox()
        self.baud_combo.addItems(["9600","19200","38400","57600","115200"])
        self.baud_combo.setCurrentText("9600")
        self.connect_btn = QPushButton("连接")
        self.connect_btn.clicked.connect(self.toggle_connection)
        self.status_indicator = QLabel()
        self.status_indicator.setFixedSize(20,20)
        toolbar.addWidget(QLabel("端口:"))
        toolbar.addWidget(self.port_combo)
        toolbar.addWidget(QLabel("波特率:"))
        toolbar.addWidget(self.baud_combo)
        toolbar.addWidget(QPushButton("刷新", clicked=self.refresh_ports))
        toolbar.addWidget(self.connect_btn)
        toolbar.addWidget(self.status_indicator)

    def create_mode_toolbar(self):
        toolbar = QToolBar()
        self.addToolBar(Qt.TopToolBarArea, toolbar)
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["门禁模式","添加用户","删除用户"])
        self.mode_combo.currentIndexChanged.connect(self.switch_mode)
        self.admin_btn = QPushButton("紧急开门")
        self.admin_btn.clicked.connect(self.toggle_emergency_mode)
        self.admin_btn.setEnabled(False)
        toolbar.addWidget(QLabel("工作模式:"))
        toolbar.addWidget(self.mode_combo); toolbar.addWidget(self.admin_btn)

    def init_mode_uis(self):
        # 门禁模式
        page1 = QWidget()
        l1 = QVBoxLayout(page1)
        self.door_img = QLabel()
        self.door_img.setAlignment(Qt.AlignCenter)
        self.door_img.setScaledContents(True)
        self.door_img.clear()  # 初始时不显示图片
        l1.addWidget(self.door_img)
        # 添加用户
        page2 = QWidget(); l2 = QVBoxLayout(page2)
        label2 = QLabel("请将要添加的校园卡放置在阅读器附近")
        label2.setAlignment(Qt.AlignCenter)
        label2.setStyleSheet("font-size:20px; color:black;")
        l2.addWidget(label2)
        # 删除用户
        page3 = QWidget(); l3 = QVBoxLayout(page3)
        label3 = QLabel("请将要删除的校园卡放置在阅读器附近")
        label3.setAlignment(Qt.AlignCenter)
        label3.setStyleSheet("font-size:20px; color:black;")
        l3.addWidget(label3)
        # 加入stack
        self.stack.addWidget(page1); self.stack.addWidget(page2)
        self.stack.addWidget(page3)

    def init_serial(self):
        self.serial_thread.status_updated.connect(self.handle_status)
        self.serial_thread.error_occurred.connect(self.show_error)
        self.serial_thread.connection_changed.connect(self.update_connection_status)
        self.serial_thread.start()

    def toggle_connection(self):
        if self.connect_btn.text() == "连接": self.connect_serial()
        else: self.disconnect_serial()

    def connect_serial(self):
        port = self.port_combo.currentText().split(" - ")[0]
        baud = int(self.baud_combo.currentText())
        if self.serial_thread.connect_serial(port, baud):
            self.connect_btn.setText("断开") 
            self.status_indicator.setStyleSheet("background:#4CAF50;border-radius:10px;")
            if self.mode_combo.currentIndex() == 0:
                self.is_door_open = False; self.stack.setCurrentIndex(0)
                self.update_door_image(False)
            self.admin_btn.setEnabled(True)

    def disconnect_serial(self):
        self.serial_thread.disconnect_serial()
        self.connect_btn.setText("连接")
        self.status_indicator.setStyleSheet("background:#f44336;border-radius:10px;")
        self.admin_btn.setEnabled(False)
        self.is_door_open = False
        self.stack.setCurrentIndex(0)  # 确保回到门禁界面
        self.update_door_image(None)  # 传递None清除图片

    def toggle_emergency_mode(self):
        if self.mode_combo.currentIndex() != 0: return
        if not self.emergency_mode and self.serial_thread.send_mode_command(4):
            self.emergency_mode=True
            self.is_door_open=True
            self.mode_combo.setEnabled(False)
            self.admin_btn.setText("退出紧急模式")
            self.stack.setCurrentIndex(0)
            self.update_door_image(True)
        elif self.emergency_mode and self.serial_thread.send_mode_command(1):
            self.emergency_mode=False; self.is_door_open=False
            self.mode_combo.setEnabled(True)
            self.admin_btn.setText("紧急开门"); self.stack.setCurrentIndex(0)
            self.update_door_image(False)

    def switch_mode(self, index):
        if self.emergency_mode: return
        if index in (0,1,2) and self.serial_thread.send_mode_command(index+1):
            self.stack.setCurrentIndex(index)
            # 紧急模式按钮状态
            self.admin_btn.setEnabled(self.serial_thread.connected_flag and index==0)
            if index==0: self.update_door_image(self.is_door_open)

    def update_door_image(self, open_status:bool):
        if open_status is None:  # 新增空状态处理
            self.door_img.clear()
        else:
            pix = QPixmap(f"images/door_{'open' if open_status else 'closed'}.png")
            self.door_img.setPixmap(pix)

    def update_connection_status(self, connected):
        col="#4CAF50" if connected else "#f44336"
        self.status_indicator.setStyleSheet(f"background:{col};border-radius:10px;")
        self.connect_btn.setText("断开" if connected else "连接")
        self.admin_btn.setEnabled(connected and self.mode_combo.currentIndex()==0)
        if connected and self.mode_combo.currentIndex()==0:
            self.is_door_open=False; self.stack.setCurrentIndex(0); self.update_door_image(False)

    def handle_status(self, mode, status):
        if mode==1:
            self.is_door_open=(status=="开启")
            if not self.emergency_mode: self.update_door_image(self.is_door_open)
        # elif mode==5:
        #     new_m=int(status.split(":")[1])
        #     if new_m==4: self.emergency_mode=True; self.is_door_open=True; self.stack.setCurrentIndex(0); self.update_door_image(True)
        #     elif new_m==1: self.emergency_mode=False; self.is_door_open=False; self.stack.setCurrentIndex(0); self.update_door_image(False)

    def refresh_ports(self):
        self.port_combo.clear(); self.port_combo.addItems([f"{p.device} - {p.description}" for p in list_ports.comports()])

    def show_error(self, msg):
        QMessageBox.critical(self, "错误", msg)
        if "串口" in msg: self.disconnect_serial()

APP_STYLE = '''
QMainWindow {
    background-image: url(images/background.png);
    background-repeat: no-repeat;
    background-position: center;
}
QToolBar {
    padding:5px; border-bottom:1px solid #bdc3c7;
}
QToolBar QLabel {
    color: black;
}
'''

if __name__=="__main__":
    app=QApplication(sys.argv)
    app.setStyleSheet(APP_STYLE)
    window=MainWindow()
    window.show()
    sys.exit(app.exec())
