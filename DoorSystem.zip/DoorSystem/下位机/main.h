

#include "STC15F2K60S2.H"
#include "sys.H"
#include "mfrc522.h"
#include "displayer.h"
#include "uart1.h"
#include "string.h"
#include "manageID.h"
#include "M24C02.h"
#include "Key.h"