sbit MF522_SO = P1^0;
sbit MF522_NSS = P1^1;
sbit MF522_SCK = P4^1;
sbit MF522_SI = P4^2;
sbit MF522_EA = P4^3;
sbit MF522_IIC = P4^4;

#define TRUE 1
#define FALSE 0