import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QGroupBox, QVBoxLayout,
                              QHBoxLayout, QPushButton, QLineEdit, QLabel,
                              QComboBox, QTextEdit, QMessageBox)
from PySide6.QtCore import QTimer, Qt
import serial
import serial.tools.list_ports
import time

class RFIDApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ser = None
        self.current_mode = 1  # 1-消费 2-充值
        self.last_seen = None  # 上次检测到卡片的时间戳
        self.init_ui()
        self.init_serial()
        
    def init_ui(self):
        # 主窗口设置
        self.setWindowTitle("校园卡模拟系统")
        self.setGeometry(400, 200, 600, 400)

        # 串口配置区
        serial_group = QGroupBox("串口配置")
        self.port_combo = QComboBox()
        self.refresh_btn = QPushButton("检测串口")
        self.refresh_btn.clicked.connect(self.refresh_ports)
        self.baud_combo = QComboBox()
        self.baud_combo.addItems(["9600", "115200"])
        self.connect_btn = QPushButton("连接")
        self.connect_btn.clicked.connect(self.toggle_connection)
        
        serial_layout = QHBoxLayout()
        serial_layout.addWidget(QLabel("端口:"))
        serial_layout.addWidget(self.port_combo)
        serial_layout.addWidget(self.refresh_btn)
        serial_layout.addWidget(QLabel("波特率:"))
        serial_layout.addWidget(self.baud_combo)
        serial_layout.addWidget(self.connect_btn)
        serial_group.setLayout(serial_layout)

        # 模式切换区
        mode_group = QGroupBox("操作模式")
        self.consume_btn = QPushButton("消费模式")
        self.recharge_btn = QPushButton("充值模式")
        self.consume_btn.setCheckable(True)
        self.recharge_btn.setCheckable(True)
        self.consume_btn.clicked.connect(lambda: self.set_mode(1))
        self.recharge_btn.clicked.connect(lambda: self.set_mode(2))
        
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(self.consume_btn)
        mode_layout.addWidget(self.recharge_btn)
        mode_group.setLayout(mode_layout)

        # 金额输入区
        input_group = QGroupBox("金额操作")
        self.value_input = QLineEdit()
        self.value_input.setPlaceholderText("输入金额（元）")
        self.send_btn = QPushButton("确定")
        self.send_btn.clicked.connect(self.send_command)
        
        input_layout = QHBoxLayout()
        input_layout.addWidget(self.value_input)
        input_layout.addWidget(self.send_btn)
        input_group.setLayout(input_layout)

        # 状态显示区
        self.balance_label = QLabel("当前余额：--.-- 元")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setStyleSheet("font-size: 20px; color: #2ecc71;")
        
        # 日志显示
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        # 清除日志按钮
        self.clear_btn = QPushButton("清除日志")
        self.clear_btn.clicked.connect(self.clear_log)

        # 主布局
        main_layout = QVBoxLayout()
        main_layout.addWidget(serial_group)
        main_layout.addWidget(mode_group)
        main_layout.addWidget(input_group)
        main_layout.addWidget(self.balance_label)
        main_layout.addWidget(self.log_text)
        main_layout.addWidget(self.clear_btn)

        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

    def refresh_ports(self):
        """刷新串口列表"""
        self.init_serial()
        self.log_text.append("串口列表已更新")

    def clear_log(self):
        """清除日志"""
        self.log_text.clear()

    def init_serial(self):
        """初始化串口设备列表"""
        ports = serial.tools.list_ports.comports()
        self.port_combo.clear()
        for port in ports:
            self.port_combo.addItem(port.device)

    def toggle_connection(self):
        """切换串口连接状态"""
        if self.ser and self.ser.is_open:
            self.ser.close()
            self.connect_btn.setText("连接")
            self.log_text.append("连接已断开")
        else:
            try:
                self.ser = serial.Serial(
                    port=self.port_combo.currentText(),
                    baudrate=int(self.baud_combo.currentText()),
                    timeout=1
                )
                QTimer.singleShot(100, self.read_serial)
                self.connect_btn.setText("断开")
                self.log_text.append("串口连接成功")
            except Exception as e:
                self.show_error(f"连接失败: {str(e)}")

    def set_mode(self, mode):
        """设置操作模式"""
        self.current_mode = mode
        self.consume_btn.setChecked(mode == 1)
        self.recharge_btn.setChecked(mode == 2)
        self.log_text.append(f"切换到 {'消费' if mode ==1 else '充值'} 模式")
        self.send_mode_command(mode)

    def send_mode_command(self, mode):
        """发送模式切换命令"""
        if not self.ser or not self.ser.is_open:
            self.show_error("请先连接串口")
            return
        
        cmd = 0x20
        frame = self.build_frame(cmd, mode)
        self.ser.write(frame)
        self.log_text.append(f"发送模式指令: {bytes(frame).hex()}")

    def build_frame(self, cmd, value):
        """构建协议帧"""
        header = 0xAA
        length = 0x02
        
        if cmd == 0x40:  # 金额指令
            # 四舍五入处理，避免浮点截断误差
            cents = int(round(float(value) * 100))
            data_bytes = [(cents >> 8) & 0xFF, cents & 0xFF]
        else:  # 模式指令
            data_bytes = [0x00, value]
        
        frame = [header, cmd, length] + data_bytes
        checksum = sum(frame[1:]) % 256
        frame.append(checksum)
        return bytes(frame)

    def send_command(self):
        """发送金额指令"""
        if not self.validate_input():
            return
        
        cmd = 0x40
        frame = self.build_frame(cmd, self.value_input.text())
        
        try:
            self.ser.write(frame)
            self.log_text.append(f"发送指令: {bytes(frame).hex()}")
            self.value_input.clear()
        except Exception as e:
            self.show_error(f"发送失败: {str(e)}")

    def validate_input(self):
        """验证输入有效性"""
        if not self.ser or not self.ser.is_open:
            self.show_error("请先连接串口")
            return False
        
        try:
            float(self.value_input.text())
            return True
        except ValueError:
            self.show_error("请输入有效的数字金额")
            return False

    def read_serial(self):
        """读取串口数据并处理卡片离开逻辑"""
        if self.ser and self.ser.is_open:
            try:
                if self.ser.in_waiting >= 16:
                    while self.ser.in_waiting >= 16:
                        data = self.ser.read(16)
                        # 余额不足（16字节全0xFF）
                        if self.current_mode == 1 and data == b'\xff' * 16:
                            self.log_text.append("余额不足")
                            continue
                        balance = self.parse_balance(data)
                        self.update_display(balance)
                    self.last_seen = time.time()
                else:
                    if self.last_seen and (time.time() - self.last_seen) > 3:
                        self.balance_label.setText("当前余额：--.-- 元")
                        self.balance_label.setStyleSheet("font-size: 20px; color: #2ecc71;")
                        self.last_seen = None
            except Exception as e:
                self.log_text.append(f"读取错误: {str(e)}")
            
            QTimer.singleShot(100, self.read_serial)

    def parse_balance(self, data):
        """解析余额数据"""
        if len(data) >= 16:
            high_byte = data[14]
            low_byte = data[15]
            balance = (high_byte << 8) | low_byte
            return balance / 100.0
        return 0.0

    def update_display(self, balance):
        """更新界面显示"""
        self.balance_label.setText(f"当前余额：{balance:.2f} 元")
        self.balance_label.setStyleSheet(
            "font-size: 20px; color: #2ecc71;" if balance >= 0 else "font-size: 20px; color: #e74c3c;"
        )

    def show_error(self, message):
        """显示错误信息"""
        QMessageBox.critical(self, "错误", message)

    def closeEvent(self, event):
        """关闭窗口事件处理"""
        if self.ser and self.ser.is_open:
            self.ser.close()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RFIDApp()
    window.show()
    sys.exit(app.exec())
